<?php	
	define('BASE_URL','http://192.168.254.140/IRtemp/ir.php');
	date_default_timezone_set("Asia/Kuala_Lumpur");
	$timestamp = time();
	extract($_GET);
	
	$servername = "localhost";
	$username = "root";
	$password = ""; 
	$dbname = "ilogdb"; 
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	if(mysqli_connect_errno()) die("Error : " . mysqli_connect_error());
	
	if(isset($_GET['value']))
	{
		$sql = "INSERT INTO nodemcu(timestamp,value) VALUES ('$timestamp','$value')";
		if(mysqli_query($conn, $sql) === TRUE) echo "Insert at ".date("d/m/y h:i:sA",$timestamp);
	}
	else if(isset($_GET['list']))
	{
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		
		$sql = "SELECT *FROM nodemcu ORDER BY timestamp DESC";
		$result = mysqli_query($conn, $sql);
		
		$outp = '[';
		while($row = mysqli_fetch_array($result))
		{
			if ($outp != '[') {$outp .= ',';}
			$outp .= '{"timestamp":"' . date("d/m/y h:i:sA",$row['timestamp']) . '",'; 
			$outp .= '"value":"' . $row['value'] . '"}'; 
		}
		$outp .=']';
		
		echo($outp);
	}	
	else
	{
	?>
<!DOCTYPE html>
<html>
<head>
	<title>BodyTemp</title>
	<!-- jquery.com -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
	<!-- getbootstrap.com -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	
	<script>
	var xmlhttp = new XMLHttpRequest();
	var url = "<?php echo BASE_URL ?>"+"?list";
	
	setInterval(function(){	
		xmlhttp.onreadystatechange=function(){
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200){				
				var arr = JSON.parse(xmlhttp.responseText);
				var end;
				
				end=arr.length;
				if(end>0)
				{
					document.getElementById("timestamp").innerHTML = arr[0].timestamp;
					document.getElementById("value").innerHTML = arr[0].value;
				}				
			}
		}
		xmlhttp.open("GET", url, false);
		xmlhttp.send();
	}, 1000);
	</script>
</head>
<body>
	<div class="container">
	<div class="jumbotron">
		<h1>NodeMCU</h1>
	</div>	
	<h1>
	<center>
	<p>VALUE</p>
	<p id="value"></p>
	<p>UPDATED</p>
	<p id="timestamp"></p>
	</center>
	</h1>
	</div>	
</body>
</html>	
	<?php
	}	
	mysqli_close($conn);
?>